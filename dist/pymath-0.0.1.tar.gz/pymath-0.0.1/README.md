# Pymath Package

Pymath is a python package adding some math objects like lines, segments or polygons.
It's still in developpement and will be updated slowly.